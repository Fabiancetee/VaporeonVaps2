from django.db import models

# Create your models here.

class Producto(models.Model):
    idProducto=models.CharField(primary_key=True, max_length=6)
    categoria=models.CharField(max_length=20)
    nombre=models.CharField(max_length=50)


    def __str__(self):
        texto = "{0} ({1})"
        return texto.format(self.nombre, self.categoria)
    
class Empleado(models.Model):
    idEmp=models.CharField(primary_key=True, max_length=6)
    Nombre=models.CharField(max_length=20)
    Apellido=models.CharField(max_length=50)
    Rut=models.CharField(max_length=50)
    Correo=models.CharField(max_length=50)
    Sueldo=models.CharField(max_length=10)


    def __str__(self):
        texto = "{0} ({1})"
        return texto.format(self.idEmp, self.Nombre)
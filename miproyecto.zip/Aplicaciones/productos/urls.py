from django.urls import path
from . import views

urlpatterns = [
    path('', views.home,name='home'),
    path('index/', views.index,name='index'),
    path('signup/', views.signup, name='signup'),
    path('logout/', views.signout, name='logout'),
    path('signin/', views.signin, name='signin'),
    path('registrarProducto/', views.registrarProducto),
    path('modificacionProducto/<idProducto>', views.modificacionProducto),
    path('modificacionProducto/', views.modificarProducto),
    path('eliminarProducto/<idProducto>', views.eliminarProducto),
    
   
    
]